package com.example.calculator;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;


import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class MainActivity extends AppCompatActivity {

    private EditText num1EditText, num2EditText;
    private TextView resultTextView;
    private Button btnplusbutton, btnminusbutton, btnmulbutton, btndividebutton, btnclearbutton;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        num1EditText = findViewById(R.id.num2);
        num2EditText = findViewById(R.id.num1);
        resultTextView = findViewById(R.id.result);
        btnplusbutton = findViewById(R.id.btnplus);
        btnminusbutton = findViewById(R.id.btnminus);
        btnmulbutton = findViewById(R.id.btnmul);
        btndividebutton = findViewById(R.id.btndivide);
        btnclearbutton = findViewById(R.id.btnclear);


        // Addition
        btnplusbutton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                performOperation("add");
            }
        });

        //Subtraction
        btnminusbutton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                performOperation("subtract");
            }
        });

        // Multiplication
        btnmulbutton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                performOperation("multiply");
            }
        });

        // Division
        btndividebutton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                performOperation("divide");
            }
        });

        //clear button
        btnclearbutton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                num1EditText.setText("");
                num2EditText.setText("");
                resultTextView.setText("0.00");
                num2EditText.requestFocus();
            }
        });
    }
    private void performOperation(String operation) {
        try {
            double num1 = Double.parseDouble(num1EditText.getText().toString());
            double num2 = Double.parseDouble(num2EditText.getText().toString());
            double result = 0;
            switch (operation) {
                case "add":
                    result = num1 + num2;
                    break;
                case "subtract":
                    result = num2 - num1;
                    break;
                case "multiply":
                    result = num1 * num2;
                    break;
                case "divide":
                    if (num1 != 0) {
                        result = num2 / num1;
                    } else {
                        resultTextView.setText("Cannot divide by zro");
                        return;
                    }
                    break;
            }
            resultTextView.setText(String.valueOf(result));
        } catch (NumberFormatException e) {
            resultTextView.setText("Invalid input");
        }
    }
}
